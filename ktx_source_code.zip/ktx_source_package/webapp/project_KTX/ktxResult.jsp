<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="java.util.List" %>
<%@ page import="project_KTX.KTXDO" %>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">

    <title>KTX 검색 결과</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fa;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #1f4e79;
            color: white;
            padding: 25px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
        }

        .container {
            width: 900px;
            margin: 40px auto;
        }

        .card {
            background-color: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        }

        .search-info {
            margin-bottom: 10px;
        }

        .train {
            border: 1px solid #ddd;
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 8px;
        }

        .train-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .time {
            font-size: 22px;
            font-weight: bold;
        }

        .route {
            margin-top: 8px;
            color: #555;
        }

        .seat {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }

        .button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #1f4e79;
            color: white;
            cursor: pointer;
        }

        .button:hover {
            background-color: #163a5c;
        }

        .back {
            display: inline-block;
            margin-bottom: 20px;
            text-decoration: none;
            color: #1f4e79;
        }

        .no-result {
            text-align: center;
            padding: 30px;
        }

    </style>

</head>


<body>


    <!-- 상단 -->
    <div class="header">

        <h1>KTX 취소표 알림 서비스</h1>

        <p>
            KTX 열차 검색 결과
        </p>

    </div>


    <!-- 메인 -->
    <div class="container">


        <!-- 검색 화면으로 돌아가기 -->
        <a href="<%=request.getContextPath()%>/project_KTX/ktxMain.jsp" class="back">
            ← 검색 화면으로 돌아가기
        </a>


        <!-- 검색 조건 -->
        <div class="card">

            <h2>
                검색 조건
            </h2>

            <div class="search-info">
                출발역 :
                <strong>${departure}</strong>
            </div>

            <div class="search-info">
                도착역 :
                <strong>${arrival}</strong>
            </div>

            <div class="search-info">
                이용 날짜 :
                <strong>${travelDate}</strong>
            </div>

            <div class="search-info">
                원하는 시간대 :
                <strong>${timeRange}</strong>
            </div>

            <div class="search-info">
                인원 :
                <strong>${people}명</strong>
            </div>

            <div class="search-info">
                좌석 종류 :
                <strong>${seatType}</strong>
            </div>

        </div>

        <form method="post"
      	action="<%=request.getContextPath()%>/KTX_train?action=alert">

  		  <input type="hidden"
           name="departure"
           value="${departure}">

    	  <input type="hidden"
           name="arrival"
           value="${arrival}">

    	  <input type="hidden"
           name="travelDate"
           value="${travelDate}">

    	  <input type="hidden"
           name="timeRange"
           value="${timeRange}">

    	  <input type="hidden"
           name="people"
           value="${people}">

    	  <input type="hidden"
           name="seatType"
           value="${seatType}">

    	  <button type="submit" class="button">
          취소표 알림 등록
    	</button>

	    </form>


        <!-- 검색 결과 -->
        <div class="card">

            <h2>
                열차 검색 결과
            </h2>


            <%

                List<KTXDO> trainList =
                    (List<KTXDO>) request.getAttribute("trainList");


                if (trainList == null || trainList.isEmpty()) {

            %>


                <!-- 검색 결과가 없는 경우 -->

                <div class="no-result">

                    <p>
                        조건에 맞는 열차가 없습니다.
                    </p>

                    <p>
                        다른 시간대를 선택해서 다시 검색해주세요.
                    </p>

                </div>


            <%

                } else {

                    for (KTXDO train : trainList) {

            %>


                        <!-- 열차 한 개 -->

                        <div class="train">


                            <div class="train-info">


                                <div>

                                    <div class="time">

                                        <%= train.getDepartureTime() %>

                                        →

                                        <%= train.getArrivalTime() %>

                                    </div>


                                    <div class="route">

                                        <%= train.getDeparture() %>

                                        →

                                        <%= train.getArrival() %>

                                    </div>

                                </div>


                                <div>

                                    <form method="get"
                                          action="<%=request.getContextPath()%>/KTX_train">

                                        <input type="hidden"
                                               name="action"
                                               value="booking">

                                        <input type="hidden"
                                               name="trainId"
                                               value="<%=train.getTrainId()%>">

                                        <button type="submit" class="button">
                                            예매하기
                                        </button>

                                    </form>

                                </div>


                            </div>


                            <!-- 좌석 정보 -->

                            <div class="seat">

                                일반실 :
                                <strong>
                                    <%= train.getGeneralSeat() %>석
                                </strong>

                                &nbsp;&nbsp;&nbsp;

                                특실 :
                                <strong>
                                    <%= train.getSpecialSeat() %>석
                                </strong>

                            </div>


                        </div>


            <%

                    }

                }

            %>


        </div>


    </div>


</body>

</html>
