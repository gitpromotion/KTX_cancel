<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="project_KTX.KTXDO" %>
<%
    KTXDO train =
        (KTXDO) request.getAttribute("train");

    // train이 없으면(직접 접속/새로고침 등) 에러 대신 메인화면으로 돌려보냄
    if (train == null) {
        response.sendRedirect(request.getContextPath() + "/project_KTX/ktxMain.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">

    <title>KTX 예매 직전 확인</title>

    <style>

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f7fa;
        }

        .header {
            background-color: #1f4e79;
            color: white;
            text-align: center;
            padding: 25px;
        }

        .container {
            width: 700px;
            margin: 50px auto;
        }

        .card {
            background-color: white;
            padding: 35px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.1);
        }

        .title {
            text-align: center;
            margin-bottom: 30px;
        }

        .title h2 {
            margin-bottom: 10px;
        }

        .route {
            text-align: center;
            font-size: 28px;
            font-weight: bold;
            margin: 30px 0;
        }

        .info {
            display: flex;
            justify-content: space-between;
            padding: 15px 0;
            border-bottom: 1px solid #eeeeee;
        }

        .seat-box {
            margin-top: 25px;
            padding: 20px;
            background-color: #f1f3f5;
            border-radius: 8px;
            text-align: center;
        }

        .seat-box strong {
            display: block;
            font-size: 24px;
            margin-top: 8px;
        }

        .notice {
            margin-top: 25px;
            padding: 18px;
            background-color: #fff3cd;
            border-radius: 8px;
            text-align: center;
        }

        .button-area {
            text-align: center;
            margin-top: 30px;
        }

        .booking-button {
            display: inline-block;
            padding: 15px 35px;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 7px;
            font-size: 17px;
            font-weight: bold;
        }

        .back {
            display: block;
            margin-top: 20px;
            text-align: center;
            color: #555555;
            text-decoration: none;
        }

    </style>
</head>
<body>

<div class="header">
    <h1>KTX 취소표 알림 서비스</h1>
    <p>예매 직전 확인</p>
</div>

<div class="container">

    <div class="card">

        <div class="title">
            <h2>예매 정보를 확인해주세요</h2>
            <p>
                발견된 취소표의 정보를 확인한 후
                공식 예매 페이지로 이동합니다.
            </p>

        </div>


        <div class="route">
            <%= train.getDeparture() %>
            →
            <%= train.getArrival() %>

        </div>


        <div class="info">

            <span>이용 날짜</span>
            <strong>
                <%= train.getTravelDate() %>
            </strong>
        </div>


        <div class="info">
            <span>출발 시간</span>
            <strong>
                <%= train.getDepartureTime() %>
            </strong>
        </div>


        <div class="info">
            <span>도착 시간</span>
            <strong>
                <%= train.getArrivalTime() %>
            </strong>
        </div>

        <div class="seat-box">

            일반실 잔여 좌석

            <strong>
                <%= train.getGeneralSeat() %>석
            </strong>
        </div>


        <div class="notice">
            현재 좌석이 확인되었습니다.
            <br>
            좌석은 실시간으로 변경될 수 있습니다.

        </div>

        <div class="button-area">
            <a
                href="https://www.korail.com/ticket/search"
                target="_blank"
                class="booking-button">
                코레일 공식 예매로 이동
            </a>
        </div>

        <a
            href="<%=request.getContextPath()%>/project_KTX/ktxMain.jsp"
            class="back">
            ← KTX 검색 화면으로 돌아가기
        </a>

    </div>


</div>

</body>
</html>
