<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>KTX 취소표 알림 서비스 - 로그인</title>

<style>

    * {
        box-sizing: border-box;
    }

    body {
        font-family: 'Malgun Gothic', Arial, sans-serif;
        background-color: #f5f7fa;
        margin: 0;
        padding: 0;
    }

    .header {
        background-color: #1f4e79;
        color: white;
        padding: 30px 20px;
        text-align: center;
    }

    .header h1 {
        margin: 0;
        font-size: 26px;
    }

    .header p {
        margin: 10px 0 0;
        font-size: 14px;
        opacity: 0.9;
    }

    .container {
        width: 380px;
        max-width: 90%;
        margin: 50px auto;
    }

    .card {
        background-color: white;
        padding: 35px 30px;
        border-radius: 10px;
        box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
    }

    .card h2 {
        text-align: center;
        margin-top: 0;
        margin-bottom: 25px;
        color: #1f4e79;
        font-size: 20px;
    }

    .form-group {
        margin-bottom: 18px;
    }

    .form-group label {
        display: block;
        font-weight: bold;
        margin-bottom: 6px;
        font-size: 14px;
        color: #333;
    }

    .form-group input {
        width: 100%;
        padding: 11px 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 14px;
    }

    .form-group input:focus {
        outline: none;
        border-color: #1f4e79;
    }

    .btn-primary {
        width: 100%;
        padding: 12px;
        border: none;
        border-radius: 5px;
        background-color: #1f4e79;
        color: white;
        font-size: 15px;
        font-weight: bold;
        cursor: pointer;
        margin-top: 5px;
    }

    .btn-primary:hover {
        background-color: #163a5c;
    }

    .btn-outline {
        display: block;
        width: 100%;
        padding: 12px;
        border: 1px solid #1f4e79;
        border-radius: 5px;
        background-color: white;
        color: #1f4e79;
        font-size: 14px;
        text-align: center;
        text-decoration: none;
        margin-top: 10px;
        box-sizing: border-box;
    }

    .btn-outline:hover {
        background-color: #eef5fb;
    }

    .error-box {
        margin-top: 15px;
        padding: 12px;
        background-color: #fdecea;
        border-radius: 5px;
        color: #c62828;
        font-size: 14px;
        text-align: center;
    }

</style>

</head>
<body>

    <div class="header">
        <h1>KTX 취소표 알림 서비스</h1>
        <p>원하는 열차의 취소표가 나오면 바로 알려드립니다</p>
    </div>

    <div class="container">
        <div class="card">

            <h2>로그인</h2>

            <!-- 로그인 폼 -->
            <form method="post"
                  action="<%=request.getContextPath()%>/KTX_user?action=login">

                <div class="form-group">
                    <label for="username">아이디</label>
                    <input type="text"
                           id="username"
                           name="username"
                           placeholder="아이디를 입력하세요"
                           required>
                </div>

                <div class="form-group">
                    <label for="password">비밀번호</label>
                    <input type="password"
                           id="password"
                           name="password"
                           placeholder="비밀번호를 입력하세요"
                           required>
                </div>

                <button type="submit" class="btn-primary">
                    로그인
                </button>

            </form>

            <!-- 오류 메시지 -->
            <% if (request.getAttribute("error") != null) { %>
                <div class="error-box">
                    <%= request.getAttribute("error") %>
                </div>
            <% } %>

            <!-- 회원가입 -->
            <a href="<%=request.getContextPath()%>/project_KTX/join.jsp"
               class="btn-outline">
                회원가입
            </a>

        </div>
    </div>

</body>
</html>
