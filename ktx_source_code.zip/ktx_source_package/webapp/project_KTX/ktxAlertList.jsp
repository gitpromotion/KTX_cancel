<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="project_KTX.KTXAlertDO" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="20">
<title>내 취소표 알림</title>
<style>
	body {
		font-family: Arial, sans-serif;
		background-color: #f5f7fa;
		margin: 0;
		padding: 0;
	}

	.header {
		background-color: #1f4e79;
		color: white;
		padding: 25px;
		text-align: center;
	}

	.container {
		width: 900px;
		margin: 40px auto;
	}

	.card {
		background-color: white;
		padding: 25px;
		border-radius: 10px;
		margin-bottom: 20px;
		box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
	}

	.alert {
		border: 1px solid #ddd;
		padding: 20px;
		margin-bottom: 15px;
		border-radius: 8px;
	}

	.route {
		font-size: 22px;
		font-weight: bold;
		margin-bottom: 15px;
	}

	.info {
		margin: 8px 0;
	}

	.status {
		display: inline-block;
		margin-top: 15px;
		padding: 6px 12px;
		border-radius: 5px;
		background-color: #eee;
	}

	.status-found {
		background-color: #e8f5e9;
		color: #2e7d32;
	}

	.actions {
		margin-top: 15px;
	}

	.actions form {
		display: inline-block;
		margin-right: 8px;
	}

	.view-button {
		padding: 8px 16px;
		border: none;
		border-radius: 5px;
		background-color: #1f4e79;
		color: white;
		cursor: pointer;
		font-weight: bold;
	}

	.empty {
		text-align: center;
		padding: 30px;
	}

	.back {
		display: inline-block;
		margin-bottom: 20px;
		text-decoration: none;
		color: #1f4e79;
	}

  </style>
</head>
<body>
	<div class="header">
	  <h1>KTX 취소표 알림 서비스</h1>
	     <p>내 취소표 알림</p>
	</div>

	<div class="container">
	  <a href="<%=request.getContextPath()%>/project_KTX/ktxMain.jsp" class="back">
		← KTX 검색 화면으로 돌아가기
	  </a>

	<div class="card">
	  <h2>등록된 알림</h2>
	    <% List<KTXAlertDO> alertList = (List<KTXAlertDO>)request.getAttribute("alertList");
	       if (alertList == null || alertList.isEmpty()) {%>

	<div class="empty">
	   <p>등록된 취소표 알림이 없습니다</p>
	</div>

	<%
	 } else {
	 	 for (KTXAlertDO alert : alertList) {
	 %>

	 <div class="alert">

	 <div class="route">
	 	<%=alert.getDeparture() %>
	 	->
	 	<%= alert.getArrival() %>
	 	</div>

	 	<div class="info">

	 	  이용 날짜:
	 	  <strong>
	 	     <%= alert.getTravelDate() %>
	 	     </strong>
	 	  </div>

	 	  <div class="info">

	 	    원하는 시간대:
	 	    <strong>
	 	    	<%= alert.getTimeRange() %>
	 	    	</strong>
	 	   </div>

	 	   <div class="info">

	 	      인원:
	 	      <strong>
	 	    	<%= alert.getPeople() %>명
	 	      </strong>
	 	    </div>

	 	    <div class="info">

	 	       좌석 종류:
	 	       <strong>
	 	      	 <%= alert.getSeatType() %>
	 	       </strong>
	 	     </div>

	 	     <div class="status <%= "FOUND".equals(alert.getAlertStatus()) ? "status-found" : "" %>">

	 	        상태:
	 	        <strong>
	 	     	   <%= alert.getAlertStatus() %>
	 	        </strong>
	 	   </div>

	 	   <div class="actions">

	 	   <% if ("FOUND".equals(alert.getAlertStatus())) { %>
	 	   <form method="get"
	 	         action="<%=request.getContextPath()%>/KTX_train">
	 	       <input type="hidden" name="action" value="viewFound">
	 	       <input type="hidden" name="alertId" value="<%=alert.getAlertId()%>">
	 	       <button type="submit" class="view-button">예매 가능한 열차 보기</button>
	 	   </form>
	 	   <% } %>

	 	   <form method="post"
   			      action="<%=request.getContextPath()%>/KTX_train?action=deleteAlert">

  		   <input type="hidden"
         	      name="alertId"
                  value="<%=alert.getAlertId()%>">

    	   		<button type="submit">
               	    알림 삭제
    	   	    </button>

		    </form>

		    </div>

	 	 </div>
	     <%
	     		}
	     	}

	      %>
	  </div>

	</div>

</body>
</html>
