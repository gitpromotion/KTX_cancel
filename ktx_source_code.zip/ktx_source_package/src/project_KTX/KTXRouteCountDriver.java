import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

// KTX_TRAIN 데이터(CSV)를 읽어서 노선(출발역->도착역)별 운행 횟수를 집계하는 MapReduce 잡
// 입력 CSV 컬럼 순서: TRAIN_ID,DEPARTURE,ARRIVAL,TRAVEL_DATE,DEPARTURE_TIME,ARRIVAL_TIME,GENERAL_SEAT,SPECIAL_SEAT
public class KTXRouteCountDriver {

    // Mapper: 한 줄(열차 한 건)마다 "출발역->도착역" 키로 1을 emit
    public static class RouteMapper
            extends Mapper<Object, Text, Text, IntWritable> {

        private final static IntWritable one = new IntWritable(1);
        private Text routeKey = new Text();

        @Override
        public void map(Object key, Text value, Context context)
                throws IOException, InterruptedException {

            String line = value.toString();

            if (line.trim().isEmpty()) {
                return;
            }

            String[] fields = line.split(",");

            if (fields.length < 3) {
                return;
            }

            String departure = stripQuotes(fields[1].trim());
            String arrival = stripQuotes(fields[2].trim());

            // CSV 헤더 줄은 건너뜀 (H2 CSVWRITE가 큰따옴표를 붙여서 내보내므로
            // 따옴표를 벗겨낸 뒤에 비교해야 정확히 걸러짐)
            if (departure.equalsIgnoreCase("DEPARTURE") && arrival.equalsIgnoreCase("ARRIVAL")) {
                return;
            }

            routeKey.set(departure + "->" + arrival);
            context.write(routeKey, one);
        }

        // H2 CSVWRITE가 문자열 값에 자동으로 붙이는 큰따옴표를 제거
        private static String stripQuotes(String s) {
            if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
                return s.substring(1, s.length() - 1);
            }
            return s;
        }
    }

    // Reducer: 같은 노선끼리 카운트 합산
    public static class RouteReducer
            extends Reducer<Text, IntWritable, Text, IntWritable> {

        private IntWritable result = new IntWritable();

        @Override
        public void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {

            int sum = 0;

            for (IntWritable val : values) {
                sum += val.get();
            }

            result.set(sum);
            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {

        if (args.length != 2) {
            System.err.println("사용법: KTXRouteCountDriver <input path> <output path>");
            System.exit(1);
        }

        Configuration conf = new Configuration();

        Job job = Job.getInstance(conf, "KTX Route Count");

        job.setJarByClass(KTXRouteCountDriver.class);

        job.setMapperClass(RouteMapper.class);
        job.setCombinerClass(RouteReducer.class);
        job.setReducerClass(RouteReducer.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
