package project_KTX;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

// Tomcat 시작/종료 시 취소표 자동 확인 스케줄러를 켜고 끄는 역할
@WebListener
public class KTXSchedulerListener implements ServletContextListener {

    private KTXAlertPoller poller;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        poller = new KTXAlertPoller();
        poller.start();
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        if (poller != null) {
            poller.stop();
        }
    }
}
