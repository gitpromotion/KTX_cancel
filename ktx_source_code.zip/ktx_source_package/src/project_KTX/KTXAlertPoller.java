package project_KTX;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

// 취소표 알림 자동 확인기 (가상 H2 KTX_TRAIN 기준, 사이트 스크래핑 아님 - 완전 안전)
public class KTXAlertPoller {

    private final ScheduledExecutorService scheduler =
            Executors.newSingleThreadScheduledExecutor();

    private final KTXDAO dao = new KTXDAO();
    private final KTXAlertDAO alertDao = new KTXAlertDAO();

    // 서버 시작 10초 후부터, 60초 간격으로 반복 확인
    public void start() {
        scheduler.scheduleWithFixedDelay(this::checkAllAlerts, 10, 60, TimeUnit.SECONDS);
        System.out.println("[KTX] 취소표 자동 확인 스케줄러 시작 (60초 간격)");
    }

    public void stop() {
        scheduler.shutdownNow();
    }

    private void checkAllAlerts() {
        try {

            // 현재 앱이 테스트용 고정 사용자(1번)로만 동작하므로 동일하게 맞춤
            int userId = 1;

            List<KTXAlertDO> alerts = alertDao.getAlerts(userId);

            for (KTXAlertDO alert : alerts) {

                // 이미 발견된 알림은 건너뜀
                if ("FOUND".equals(alert.getAlertStatus())) {
                    continue;
                }

                List<KTXDO> trains = dao.findAvailableTrains(
                        alert.getDeparture(),
                        alert.getArrival(),
                        alert.getTravelDate(),
                        alert.getTimeRange(),
                        alert.getSeatType()
                );

                if (!trains.isEmpty()) {

                    alertDao.updateAlertStatus(alert.getAlertId(), "FOUND");

                    System.out.println(
                            "[취소표 자동 발견] "
                            + alert.getDeparture() + " -> " + alert.getArrival()
                            + " (" + alert.getTimeRange() + ")"
                    );
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
