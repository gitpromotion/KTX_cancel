<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="java.util.List" %>
<%@ page import="project_KTX.KTXDO" %>
<%@ page import="project_KTX.KTXAlertDO" %>
   
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>취소표 발견 - 예매 안내</title>
    <style>

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f7fa;
        }

        .header {
            background-color: #1f4e79;
            color: white;
            text-align: center;
            padding: 25px;
        }

        .container {
            width: 900px;
            margin: 40px auto;
        }

        .notice {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            margin-bottom: 25px;
            text-align: center;
        }

        .notice h2 {
            margin-top: 0;
        }

        .train {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .route {
            font-size: 26px;
            font-weight: bold;
            margin-bottom: 25px;
            text-align: center;
        }

        .info {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #eee;
        }

        .info:last-of-type {
            border-bottom: none;
        }

        .seat-box {
            display: flex;
            gap: 15px;
            margin-top: 25px;
        }

        .seat {
            flex: 1;
            padding: 18px;
            border-radius: 8px;
            text-align: center;
            background-color: #f1f3f5;
        }

        .seat strong {
            display: block;
            font-size: 22px;
            margin-top: 8px;
        }

        .booking {
            text-align: center;
            margin-top: 30px;
        }

        .booking-button {
            display: inline-block;
            padding: 15px 35px;
            background-color: #1f4e79;
            color: white;
            text-decoration: none;
            border-radius: 7px;
            font-size: 17px;
            font-weight: bold;
        }

        .booking-button:hover {
            opacity: 0.9;
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 25px;
            color: #555;
            text-decoration: none;
        }

        .guide {
            margin-top: 15px;
            color: #777;
            font-size: 14px;
        }

    </style>
</head>
<body>
	   <div class="header">
    	<h1>KTX 취소표 알림 서비스</h1>
  	    <p>취소표 발견</p>

	  </div>


	  <div class="container">
    	<div class="notice">
        <h2>취소표가 발생했습니다!</h2>
        <p>등록하신 조건에 맞는 좌석이 확인되었습니다.</p>
        <p>아래 열차 정보를 확인한 후 예매를 진행해주세요.</p>
     </div>

    <%
        KTXAlertDO alert =
            (KTXAlertDO)
            request.getAttribute("foundAlert");


        List<KTXDO> trainList =
            (List<KTXDO>)
            request.getAttribute("availableTrains");
    %>

    <%

        if (trainList != null) {

            for (KTXDO train : trainList) {

    %>


    <div class="train">
        <div class="route">
            <%= train.getDeparture() %>
            →
            <%= train.getArrival() %>
        </div>
        
        <div class="info">
            <span>이용 날짜</span>
            <strong>
                <%= train.getTravelDate() %>
            </strong>
        </div>

        <div class="info">
            <span>출발 시간</span>
            <strong>
                <%= train.getDepartureTime() %>
            </strong>
        </div>

        <div class="info">
            <span>도착 시간</span>
            <strong>
                <%= train.getArrivalTime() %>
            </strong>
        </div>

        <div class="seat-box">
            <div class="seat">
                일반실
                <strong>
                    <%= train.getGeneralSeat() %>석
                </strong>
            </div>

            <div class="seat">
                특실
                <strong>
                    <%= train.getSpecialSeat() %>석
                </strong>
            </div>
        </div>
      
       <div class="booking">

      <form method="get"
            action="<%=request.getContextPath()%>/KTX_train">

        <input type="hidden"
               name="action"
               value="booking">

        <input type="hidden"
               name="trainId"
               value="<%=train.getTrainId()%>">

        <input type="hidden"
               name="departure"
               value="<%=train.getDeparture()%>">

        <input type="hidden"
               name="arrival"
               value="<%=train.getArrival()%>">

        <input type="hidden"
               name="travelDate"
               value="<%=train.getTravelDate()%>">

        <input type="hidden"
               name="departureTime"
               value="<%=train.getDepartureTime()%>">

        <input type="hidden"
               name="arrivalTime"
               value="<%=train.getArrivalTime()%>">

        <input type="hidden"
               name="generalSeat"
               value="<%=train.getGeneralSeat()%>">

        <input type="hidden"
               name="specialSeat"
               value="<%=train.getSpecialSeat()%>">

        <button type="submit"
                class="booking-button">
            		예매하기
        </button>

      </form>

   		 <p class="guide">
      	    발견된 열차의 예매 정보를 확인합니다.
   		 </p>

	 </div>

    </div>

    <%

            }

        }

    %>


    <a
        href="<%=request.getContextPath()%>/project_KTX/ktxMain.jsp"
        class="back">
        ← KTX 검색 화면으로 돌아가기
    </a>


</div>

</body>
</html>