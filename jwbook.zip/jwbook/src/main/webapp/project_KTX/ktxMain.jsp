<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%
    // KTX 주요 정차역 목록 (경부선/호남선/전라선/경전선/동해선/강릉선)
    String[] STATIONS = {
        "강릉","경산","곡성","공주","광명","광주송정","구례구","구포",
        "김천구미","나주","남원","대전","동대구","마산","목포","밀양",
        "부산","서울","순천","여수엑스포","여천","오송","용산","익산",
        "전주","정읍","진영","진주","창원중앙","천안아산","청량리","포항"
    };
%>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <title>KTX 취소표 알림 서비스</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fa;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #1f4e79;
            color: white;
            padding: 25px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
        }

        .header p {
            margin-top: 10px;
        }

        .container {
            width: 700px;
            margin: 40px auto;
        }

        .logout {
            text-align: right;
            margin-bottom: 15px;
        }

        .logout a {
            color: #555;
            text-decoration: none;
        }

        .card {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        }

        .title {
            text-align: center;
            margin-bottom: 30px;
        }

        .title h2 {
            margin-bottom: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .row {
            display: flex;
            gap: 20px;
        }

        .row .form-group {
            flex: 1;
        }

        .swap-btn-wrap {
            display: flex;
            align-items: flex-end;
            padding-bottom: 10px;
        }

        .swap-btn {
            width: 36px;
            height: 36px;
            flex-shrink: 0;
            border-radius: 50%;
            border: 1px solid #1f4e79;
            background-color: white;
            color: #1f4e79;
            font-size: 16px;
            cursor: pointer;
        }

        .swap-btn:hover {
            background-color: #eef5fb;
        }

        .search-button {
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 5px;
            background-color: #1f4e79;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        .search-button:hover {
            background-color: #163a5c;
        }

        .notice {
            margin-top: 25px;
            padding: 15px;
            background-color: #eef5fb;
            border-radius: 5px;
            font-size: 14px;
        }

        .quick-routes {
            margin-bottom: 25px;
        }

        .quick-routes-label-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .quick-routes-label {
            font-weight: bold;
            font-size: 14px;
            color: #333;
        }

        .quick-route-add-btn {
            padding: 5px 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: white;
            color: #555;
            font-size: 12px;
            cursor: pointer;
        }

        .quick-route-add-btn:hover {
            background-color: #f0f0f0;
        }

        .quick-routes-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .quick-route-chip {
            display: inline-flex;
            align-items: center;
            border: 1px solid #1f4e79;
            border-radius: 20px;
            background-color: white;
            overflow: hidden;
        }

        .quick-route-btn {
            padding: 8px 12px;
            border: none;
            background-color: transparent;
            color: #1f4e79;
            font-size: 13px;
            cursor: pointer;
        }

        .quick-route-btn:hover {
            background-color: #eef5fb;
        }

        .quick-route-delete {
            padding: 8px 10px;
            border: none;
            border-left: 1px solid #1f4e79;
            background-color: transparent;
            color: #c62828;
            font-size: 13px;
            cursor: pointer;
        }

        .quick-route-delete:hover {
            background-color: #fdecea;
        }

        .quick-routes-empty {
            font-size: 13px;
            color: #999;
        }

    </style>

    <script>
        function setRoute(dep, arr) {
            document.getElementById('departure').value = dep;
            document.getElementById('arrival').value = arr;
        }

        function swapStations() {
            var dep = document.getElementById('departure');
            var arr = document.getElementById('arrival');
            var temp = dep.value;
            dep.value = arr.value;
            arr.value = temp;
        }

        var FAVORITES_KEY = 'ktxFavoriteRoutes';

        function loadFavoriteRoutes() {
            try {
                var raw = localStorage.getItem(FAVORITES_KEY);
                return raw ? JSON.parse(raw) : [];
            } catch (e) {
                return [];
            }
        }

        function saveFavoriteRoutes(routes) {
            try {
                localStorage.setItem(FAVORITES_KEY, JSON.stringify(routes));
            } catch (e) {
                // localStorage 사용 불가 시 조용히 무시
            }
        }

        function renderFavoriteRoutes() {
            var routes = loadFavoriteRoutes();
            var container = document.getElementById('quickRoutesContainer');
            container.innerHTML = '';

            if (routes.length === 0) {
                var empty = document.createElement('span');
                empty.className = 'quick-routes-empty';
                empty.textContent = '등록된 즐겨찾는 경로가 없습니다. 출발역/도착역을 고르고 "+ 현재 출발역/도착역 추가"를 눌러보세요.';
                container.appendChild(empty);
                return;
            }

            routes.forEach(function (route, index) {
                var chip = document.createElement('span');
                chip.className = 'quick-route-chip';

                var btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'quick-route-btn';
                btn.textContent = route.dep + ' → ' + route.arr;
                btn.onclick = function () {
                    setRoute(route.dep, route.arr);
                };

                var delBtn = document.createElement('button');
                delBtn.type = 'button';
                delBtn.className = 'quick-route-delete';
                delBtn.textContent = '×';
                delBtn.title = '즐겨찾기에서 삭제';
                delBtn.onclick = function () {
                    removeFavoriteRoute(index);
                };

                chip.appendChild(btn);
                chip.appendChild(delBtn);
                container.appendChild(chip);
            });
        }

        function addCurrentRoute() {
            var dep = document.getElementById('departure').value;
            var arr = document.getElementById('arrival').value;

            if (!dep || !arr) {
                alert('출발역과 도착역을 먼저 선택해주세요.');
                return;
            }

            if (dep === arr) {
                alert('출발역과 도착역이 같습니다.');
                return;
            }

            var routes = loadFavoriteRoutes();

            var alreadyExists = routes.some(function (r) {
                return r.dep === dep && r.arr === arr;
            });

            if (alreadyExists) {
                alert('이미 즐겨찾기에 등록된 경로입니다.');
                return;
            }

            routes.push({ dep: dep, arr: arr });
            saveFavoriteRoutes(routes);
            renderFavoriteRoutes();
        }

        function removeFavoriteRoute(index) {
            var routes = loadFavoriteRoutes();
            routes.splice(index, 1);
            saveFavoriteRoutes(routes);
            renderFavoriteRoutes();
        }

        document.addEventListener('DOMContentLoaded', renderFavoriteRoutes);
    </script>

</head>


<body>


    <!-- 상단 -->
    <div class="header">

        <h1>KTX 취소표 알림 서비스</h1>

        <p>
            원하는 조건의 KTX 열차를 검색하고 취소표 알림을 등록하세요.
        </p>

    </div>


    <!-- 메인 -->
    <div class="container">


        <!-- 로그아웃 -->
        <div class="logout">

            <a href="<%=request.getContextPath()%>/KTX_user?action=logout">
                로그아웃
            </a>

        </div>


        <div class="card">

            <!-- 알림/에러 메시지 -->
            <%
                String msg = (String) request.getAttribute("message");
                String err = (String) request.getAttribute("error");
                if (msg != null) {
            %>
                <div style="margin-bottom:20px;padding:12px;background-color:#e8f5e9;border-radius:5px;color:#2e7d32;">
                    <%= msg %>
                </div>
            <% } if (err != null) { %>
                <div style="margin-bottom:20px;padding:12px;background-color:#fdecea;border-radius:5px;color:#c62828;">
                    <%= err %>
                </div>
            <% } %>

            <!-- 제목 -->
            <div class="title">

                <h2>KTX 열차 검색</h2>

                <p>
                    출발역, 도착역, 날짜, 원하는 시간대 등을 선택하세요.
                </p>

                <p style="margin-top:8px;">
                    <a href="<%=request.getContextPath()%>/KTX_train?action=list">
                        내 취소표 알림 목록 보기
                    </a>
                </p>

            </div>


            <!-- 자주 찾는 경로 -->
            <div class="quick-routes">

                <div class="quick-routes-label-row">
                    <div class="quick-routes-label">
                        자주 찾는 경로
                    </div>

                    <button type="button" class="quick-route-add-btn"
                            onclick="addCurrentRoute()">
                        + 현재 출발역/도착역 추가
                    </button>
                </div>

                <div class="quick-routes-buttons" id="quickRoutesContainer">
                    <!-- localStorage에 저장된 즐겨찾는 경로가 여기에 표시됨 -->
                </div>

            </div>


            <!-- 검색 폼 -->
            <form method="post"
                  id="searchForm"
                  action="/jwbook/KTX_train?action=search">


                <!-- 출발역 / 도착역 -->
                <div class="row">


                    <!-- 출발역 -->
                    <div class="form-group">

                        <label for="departure">
                            출발역
                        </label>

                        <select id="departure"
                                name="departure"
                                required>

                            <option value="">
                                출발역 선택
                            </option>

                            <% for (String s : STATIONS) { %>
                            <option value="<%=s%>"><%=s%></option>
                            <% } %>

                        </select>

                    </div>


                    <!-- 출발역/도착역 바꾸기 -->
                    <div class="swap-btn-wrap">

                        <button type="button"
                                class="swap-btn"
                                onclick="swapStations()"
                                title="출발역/도착역 바꾸기">
                            ⇄
                        </button>

                    </div>


                    <!-- 도착역 -->
                    <div class="form-group">

                        <label for="arrival">
                            도착역
                        </label>

                        <select id="arrival"
                                name="arrival"
                                required>

                            <option value="">
                                도착역 선택
                            </option>

                            <% for (String s : STATIONS) { %>
                            <option value="<%=s%>"><%=s%></option>
                            <% } %>

                        </select>

                    </div>

                </div>


                <!-- 이용 날짜 -->
                <div class="form-group">

                    <label for="travelDate">
                        이용 날짜
                    </label>

                    <input type="date"
                           id="travelDate"
                           name="travelDate"
                           required>

                </div>


                <!-- 원하는 시간대 -->
                <div class="form-group">

                    <label for="timeRange">
                        원하는 시간대
                    </label>

                    <select id="timeRange"
                            name="timeRange"
                            required>

                        <option value="">
                            원하는 시간대 선택
                        </option>

                        <option value="00:00-24:00">
                            전체 시간대
                        </option>

                        <option value="05:00-09:00">
                            05:00 ~ 09:00
                        </option>

                        <option value="09:00-12:00">
                            09:00 ~ 12:00
                        </option>

                        <option value="12:00-15:00">
                            12:00 ~ 15:00
                        </option>

                        <option value="15:00-18:00">
                            15:00 ~ 18:00
                        </option>

                        <option value="18:00-21:00">
                            18:00 ~ 21:00
                        </option>

                        <option value="21:00-24:00">
                            21:00 ~ 24:00
                        </option>

                    </select>

                </div>


                <!-- 인원 / 좌석 종류 -->
                <div class="row">


                    <!-- 인원 -->
                    <div class="form-group">

                        <label for="people">
                            인원
                        </label>

                        <select id="people"
                                name="people"
                                required>

                            <option value="1">
                                1명
                            </option>

                            <option value="2">
                                2명
                            </option>

                            <option value="3">
                                3명
                            </option>

                            <option value="4">
                                4명
                            </option>

                        </select>

                    </div>


                    <!-- 좌석 종류 -->
                    <div class="form-group">

                        <label for="seatType">
                            좌석 종류
                        </label>

                        <select id="seatType"
                                name="seatType"
                                required>

                            <option value="일반실">
                                일반실
                            </option>

                            <option value="특실">
                                특실
                            </option>

                        </select>

                    </div>

                </div>


                <!-- 검색 버튼 -->
                <button type="submit"
                        class="search-button">

                    KTX 열차 검색

                </button>


            </form>


            <!-- 안내 -->
            <div class="notice">

                <strong>서비스 안내</strong>

                <p>
                    경부선·호남선·전라선 등 KTX 주요 노선 전 구간의 열차를 검색할 수 있습니다.
                </p>

                <p>
                    원하는 시간대에 맞는 열차를 확인하고,
                    매진된 열차는 취소표 알림을 등록할 수 있습니다.
                </p>

            </div>


        </div>

    </div>


</body>
</html>