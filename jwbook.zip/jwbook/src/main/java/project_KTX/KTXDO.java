package project_KTX;

public class KTXDO {
	private int trainId;

    private String departure;

    private String arrival;

    private String travelDate;

    private String departureTime;

    private String arrivalTime;

    private int generalSeat;

    private int specialSeat;


    public int getTrainId() {
        return trainId;
    }

    public void setTrainId(int trainId) {
        this.trainId = trainId;
    }


    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }


    public String getArrival() {
        return arrival;
    }

    public void setArrival(String arrival) {
        this.arrival = arrival;
    }


    public String getTravelDate() {
        return travelDate;
    }

    public void setTravelDate(String travelDate) {
        this.travelDate = travelDate;
    }


    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }


    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }


    public int getGeneralSeat() {
        return generalSeat;
    }

    public void setGeneralSeat(int generalSeat) {
        this.generalSeat = generalSeat;
    }


    public int getSpecialSeat() {
        return specialSeat;
    }

    public void setSpecialSeat(int specialSeat) {
        this.specialSeat = specialSeat;
    }
}
