package project_KTX;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {

	final String JDBC_DRIVER = "org.h2.Driver";
	final String JDBC_URL = "jdbc:h2:tcp://localhost/~/jwbookdb";
	
	public Connection open() throws Exception {

	    Connection conn = null;

	    Class.forName(JDBC_DRIVER);

	    conn = DriverManager.getConnection(
	            JDBC_URL,
	            "jwbook",
	            "1234"
	    );

	    return conn;
	}

	
    public UserDO login(String username, String password) {

    	 Connection conn = null;
    	    PreparedStatement pstmt = null;
    	    ResultSet rs = null;

    	    UserDO user = null;

    	    String sql =
    	            "SELECT USER_ID, USERNAME, PASSWORD, EMAIL, CREATED_AT "
    	            + "FROM USERS "
    	            + "WHERE USERNAME = ? AND PASSWORD = ?";

    	    try {

    	        // DB 연결
    	        conn = open();

    	        // SQL 준비
    	        pstmt = conn.prepareStatement(sql);

    	        // ?에 값 전달
    	        pstmt.setString(1, username);
    	        pstmt.setString(2, password);

    	        // SQL 실행
    	        rs = pstmt.executeQuery();

    	        // 조회 결과가 있으면
    	        if (rs.next()) {

    	            user = new UserDO();

    	            user.setUserId(rs.getInt("USER_ID"));
    	            user.setUsername(rs.getString("USERNAME"));
    	            user.setPassword(rs.getString("PASSWORD"));
    	            user.setEmail(rs.getString("EMAIL"));
    	            user.setCreatedAt(rs.getTimestamp("CREATED_AT"));
    	        }

    	    } catch (Exception e) {

    	        e.printStackTrace();

    	    } finally {

    	        try {
    	            if (rs != null) {
    	                rs.close();
    	            }

    	            if (pstmt != null) {
    	                pstmt.close();
    	            }

    	            if (conn != null) {
    	                conn.close();
    	            }

    	        } catch (Exception e) {

    	            e.printStackTrace();
    	        }
    	    }

    	    return user;
    	}

    public void join(String username, String password, String email)
            throws Exception {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            conn = open();

            String sql =
                    "INSERT INTO USERS (username, password, email) "
                    + "VALUES (?, ?, ?)";

            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, email);

            pstmt.executeUpdate();

        } finally {

            if (pstmt != null) {
                pstmt.close();
            }

            if (conn != null) {
                conn.close();
        }
     }
  }
}