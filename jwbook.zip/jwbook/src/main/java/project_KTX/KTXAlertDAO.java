package project_KTX;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class KTXAlertDAO {

    //H2 JDBC 설정
	final String JDBC_DRIVER = "org.h2.Driver";
	final String JDBC_URL = "jdbc:h2:tcp://localhost/~/jwbookdb";
	
	//DB 연결
	public Connection open() {
		Connection conn = null;
		
		try {
		  Class.forName(JDBC_DRIVER);
		  conn = DriverManager.getConnection(JDBC_URL,"jwbook","1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	//취소표 알림등록
	public void addAlert(
			int userId,
			String departure,
			String arrival,
			String travelDate,
			String timeRange,
			int people,
			String seatType) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
	    String sql ="INSERT INTO KTX_ALERT "
                + "(USER_ID, DEPARTURE, ARRIVAL, TRAVEL_DATE, "
                + "TIME_RANGE, PEOPLE, SEAT_TYPE, ALERT_STATUS) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, 'WAITING')";
	    
	    try {
	    	
	    	//DB 연결
	    	conn = open();
	    	
	    	//SQL 준비
	    	pstmt = conn.prepareStatement(sql);
	    	
	    	//값 설정
	    	pstmt.setInt(1,  userId);
	    	pstmt.setString(2,  departure);
	    	pstmt.setString(3,  arrival);
	    	pstmt.setString(4, travelDate);
	    	pstmt.setString(5, timeRange);
	    	pstmt.setInt(6, people);
	    	pstmt.setString(7, seatType);
	    	
	    	//SQL 실행
	    	pstmt.executeUpdate();
	  
	    } catch (Exception e) {
	    	e.printStackTrace();
	    
	    } finally {
	    	
	    	try {
	    		if(pstmt != null) {
	    		   pstmt.close();
	    		}
	    		
	    		if (conn != null) {
	    			conn.close();
	    		}
	    	} catch (Exception e) {
	    		e.printStackTrace();
	    		

	    	}    
	    }	 
	}	
	// 사용자별 알림 목록 조회
	public List<KTXAlertDO> getAlerts(int userId) {

	    List<KTXAlertDO> alertList = new ArrayList<>();

	    Connection conn = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;

	    String sql =
	            "SELECT ALERT_ID, USER_ID, DEPARTURE, ARRIVAL, "
	            + "TRAVEL_DATE, TIME_RANGE, PEOPLE, SEAT_TYPE, "
	            + "ALERT_STATUS, CREATED_AT "
	            + "FROM KTX_ALERT "
	            + "WHERE USER_ID = ? "
	            + "ORDER BY ALERT_ID DESC";

	    try {

	        // DB 연결
	        conn = open();

	        // SQL 준비
	        pstmt = conn.prepareStatement(sql);

	        // 사용자 ID 설정
	        pstmt.setInt(1, userId);

	        // SQL 실행
	        rs = pstmt.executeQuery();

	        // 결과 처리
	        while (rs.next()) {

	            KTXAlertDO alert = new KTXAlertDO();

	            alert.setAlertId(rs.getInt("ALERT_ID"));
	            alert.setUserId(rs.getInt("USER_ID"));
	            alert.setDeparture(rs.getString("DEPARTURE"));
	            alert.setArrival(rs.getString("ARRIVAL"));
	            alert.setTravelDate(rs.getString("TRAVEL_DATE"));
	            alert.setTimeRange(rs.getString("TIME_RANGE"));
	            alert.setPeople(rs.getInt("PEOPLE"));
	            alert.setSeatType(rs.getString("SEAT_TYPE"));
	            alert.setAlertStatus(rs.getString("ALERT_STATUS"));
	            alert.setCreatedAt(
	                    rs.getString("CREATED_AT")
	            );

	            alertList.add(alert);
	        }

	    } catch (Exception e) {

	        e.printStackTrace();

	    } finally {

	        try {

	            if (rs != null) {
	                rs.close();
	            }

	            if (pstmt != null) {
	                pstmt.close();
	            }

	            if (conn != null) {
	                conn.close();
	            }

	        } catch (Exception e) {

	            e.printStackTrace();
	        }
	    }

	    return alertList;
	}
	
	// 사용자 알림 삭제
	public void deleteAlert(int alertId, int userId) {

	    Connection conn = null;
	    PreparedStatement pstmt = null;

	    String sql =
	            "DELETE FROM KTX_ALERT "
	            + "WHERE ALERT_ID = ? "
	            + "AND USER_ID = ?";

	    try {

	        // DB 연결
	        conn = open();

	        // SQL 준비
	        pstmt = conn.prepareStatement(sql);

	        // 삭제할 알림 번호
	        pstmt.setInt(1, alertId);

	        // 현재 사용자
	        pstmt.setInt(2, userId);

	        // SQL 실행
	        pstmt.executeUpdate();

	    } catch (Exception e) {

	        e.printStackTrace();

	    } finally {

	        try {

	            if (pstmt != null) {
	                pstmt.close();
	            }

	            if (conn != null) {
	                conn.close();
	            }

	        } catch (Exception e) {

	            e.printStackTrace();
	        }
	    }
	}
	
	public void updateAlertStatus(int alertId, String status)
	        throws Exception {

	    Connection conn = null;
	    PreparedStatement pstmt = null;

	    String sql =
	            "UPDATE KTX_ALERT "
	            + "SET ALERT_STATUS = ? "
	            + "WHERE ALERT_ID = ?";

	    try {

	        conn = open();

	        pstmt = conn.prepareStatement(sql);

	        pstmt.setString(1, status);
	        pstmt.setInt(2, alertId);

	        pstmt.executeUpdate();

	    } catch (Exception e) {

	        e.printStackTrace();
	        throw e;

	    } finally {

	        try {

	            if (pstmt != null) {
	                pstmt.close();
	            }

	            if (conn != null) {
	                conn.close();
	            }

	        } catch (Exception e) {

	            e.printStackTrace();
	        }
	    }
	}
}
