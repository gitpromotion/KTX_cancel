package project_KTX;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/KTX_user")
public class UserController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private UserDAO dao;

    // 로그인 성공 후 이동할 페이지
    private final String MAIN_PAGE = "project_KTX/ktxMain.jsp";


    // Servlet 초기화
    public void init(ServletConfig config) throws ServletException {

        super.init(config);

        dao = new UserDAO();
    }


    // 클라이언트 요청 처리
    protected void service(HttpServletRequest request,
                           HttpServletResponse response)
                           throws ServletException, IOException {

        // 한글 처리
        request.setCharacterEncoding("UTF-8");

        // 요청된 작업 확인
        String action = request.getParameter("action");

        // action이 없으면 로그인으로 처리
        if (action == null) {
            action = "login";
        }


        try {

            // 로그인
            if (action.equals("login")) {

                login(request, response);
                
            } else if (action.equals("join")) {

                join(request, response);

            } else if (action.equals("logout")) {

                logout(request, response);

            } else {

                request.setAttribute(
                        "error",
                        "잘못된 요청입니다."
                );

                request.getRequestDispatcher(
                        "project_KTX/login.jsp"
                ).forward(request, response);
            }

        } catch (Exception e) {

            e.printStackTrace();

            request.setAttribute(
                    "error",
                    "로그인 처리 중 문제가 발생했습니다."
            );

            request.getRequestDispatcher(
                    "project_KTX/login.jsp"
            ).forward(request, response);
        }
    }


    // 로그아웃 처리
    public void logout(HttpServletRequest request,
                       HttpServletResponse response)
                       throws IOException {

        // 세션이 있으면 무효화 (로그인 정보 제거)
        HttpSession session = request.getSession(false);

        if (session != null) {
            session.invalidate();
        }

        // 로그인 화면으로 이동
        response.sendRedirect("project_KTX/login.jsp");
    }


    // 로그인 처리
    public void login(HttpServletRequest request,
                      HttpServletResponse response)
                      throws ServletException, IOException {

        // login.jsp에서 아이디와 비밀번호 가져오기
        String username = request.getParameter("username");
        String password = request.getParameter("password");


        // 아이디 또는 비밀번호를 입력하지 않은 경우
        if (username == null || username.trim().isEmpty()
                || password == null || password.trim().isEmpty()) {

            request.setAttribute(
                    "error",
                    "아이디와 비밀번호를 입력해주세요."
            );

            request.getRequestDispatcher(
                    "project_KTX/login.jsp"
            ).forward(request, response);

            return;
        }


        // UserDAO에서 로그인 확인
        UserDO user = dao.login(username, password);
       
        // 로그인 성공
        if (user != null) {
            // 세션 생성
            HttpSession session = request.getSession();
            // 로그인한 사용자 정보 저장
            session.setAttribute("user", user);
            // KTX 메인 화면으로 이동
            response.sendRedirect(MAIN_PAGE);
        }
        
        // 로그인 실패
        else {

            request.setAttribute(
                    "error",
                    "아이디 또는 비밀번호가 잘못되었습니다."
            );
            request.getRequestDispatcher(
                    "project_KTX/login.jsp"
            ).forward(request, response);
        }
    }

//회원가입 처리
public void join(HttpServletRequest request,
              HttpServletResponse response)
              throws ServletException, IOException {

 // join.jsp에서 회원정보 가져오기
 String username = request.getParameter("username");
 String password = request.getParameter("password");
 String email = request.getParameter("email");


 // 입력값 확인
 if (username == null || username.trim().isEmpty()
         || password == null || password.trim().isEmpty()
         || email == null || email.trim().isEmpty()) {

     request.setAttribute(
             "error",
             "모든 항목을 입력해주세요."
     );

     request.getRequestDispatcher(
             "project_KTX/join.jsp"
     ).forward(request, response);

     return;
 	 }


 	 try {

     // UserDAO를 이용하여 회원가입
     dao.join(username, password, email);

     // 회원가입 성공
     response.sendRedirect(
             "project_KTX/login.jsp"
     );

 	} catch (Exception e) {

 	    e.printStackTrace();

 	    request.setAttribute(
 	            "error",
 	            "회원가입 중 문제가 발생했습니다."
 	    );

 	    request.getRequestDispatcher(
 	            "project_KTX/join.jsp"
 	    ).forward(request, response);
 	
 	}
   }
 }