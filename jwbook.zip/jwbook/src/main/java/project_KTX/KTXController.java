package project_KTX;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/KTX_train")
public class KTXController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private KTXDAO dao;
    private KTXAlertDAO alertDao;

    private final String MAIN_PAGE =
            "project_KTX/ktxMain.jsp";

    private final String RESULT_PAGE =
            "project_KTX/ktxResult.jsp";


    // Servlet 초기화
    public void init() throws ServletException {

        super.init();

        dao = new KTXDAO();
        alertDao = new KTXAlertDAO();
    }


    // 클라이언트 요청 처리
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String action =
                request.getParameter("action");


        if (action == null) {
            action = "search";
        }


        try {

            if (action.equals("search")) {
                search(request, response);

           } else if (action.equals("alert")) {
                addAlert(request, response);

           } else if (action.equals("list")) {
        	    alertList(request, response);

           } else if (action.equals("deleteAlert")) {
        	    deleteAlert(request, response);

           } else if (action.equals("available")) {
        	    availableTrains(request, response);
           } else if (action.equals("checkAlerts")) {
        	    checkAlerts(request, response);
           } else if (action.equals("viewFound")) {
                viewFound(request, response);
           } else if (action.equals("booking")) {
        	        booking(request, response);

           } else {
                request.setAttribute(
                        "error",
                        "잘못된 요청입니다."
                );

                request.getRequestDispatcher(
                        MAIN_PAGE
                ).forward(request, response);
            }


        } catch (Exception e) {

            e.printStackTrace();

            request.setAttribute(
                    "error",
                    "KTX 열차 검색 중 문제가 발생했습니다."
            );

            request.getRequestDispatcher(
                    MAIN_PAGE
            ).forward(request, response);
        }
    }


    // KTX 열차 검색
    public void search(HttpServletRequest request, HttpServletResponse response) throws Exception {


        String departure =
                request.getParameter("departure");

        String arrival =
                request.getParameter("arrival");

        String travelDate =
                request.getParameter("travelDate");

        String timeRange =
                request.getParameter("timeRange");

        String peopleStr =
                request.getParameter("people");

        String seatType =
                request.getParameter("seatType");


        // 출발역과 도착역이 같은 경우
        if (departure == null
                || arrival == null
                || departure.equals(arrival)) {

            request.setAttribute(
                    "error",
                    "출발역과 도착역을 다르게 선택해주세요."
            );

            request.getRequestDispatcher(
                    MAIN_PAGE
            ).forward(request, response);

            return;
        }


        // 인원
        int people =
                Integer.parseInt(peopleStr);


        // DAO에 검색 요청
        List<KTXDO> trainList =
                dao.searchTrain(departure, arrival, travelDate, timeRange, people, seatType);

        // 검색 조건 전달
        request.setAttribute(
                "departure",
                departure
        );

        request.setAttribute(
                "arrival",
                arrival
        );

        request.setAttribute(
                "travelDate",
                travelDate
        );

        request.setAttribute(
                "timeRange",
                timeRange
        );

        request.setAttribute(
                "people",
                people
        );

        request.setAttribute(
                "seatType",
                seatType
        );


        // 검색 결과 전달
        request.setAttribute(
                "trainList",
                trainList
        );


        // 결과 페이지 이동
        request.getRequestDispatcher(
                RESULT_PAGE
        ).forward(request, response);
    }

    public void addAlert(HttpServletRequest request, HttpServletResponse response) throws Exception {

        String departure =
                request.getParameter("departure");

        String arrival =
                request.getParameter("arrival");

        String travelDate =
                request.getParameter("travelDate");

        String timeRange =
                request.getParameter("timeRange");

        String peopleStr =
                request.getParameter("people");

        String seatType =
                request.getParameter("seatType");


        int people =
                Integer.parseInt(peopleStr);


        // 현재 테스트용 사용자 ID
        int userId = 1;


        // 알림 등록
        alertDao.addAlert(userId, departure, arrival, travelDate, timeRange, people, seatType);

        // 알림 등록 후 검색 화면으로 이동
        request.setAttribute(
                "message",
                "취소표 알림이 등록되었습니다."
        );


        request.getRequestDispatcher(
                MAIN_PAGE
        ).forward(request, response);
    }

    public void alertList(HttpServletRequest request, HttpServletResponse response) throws Exception {

        // 현재 테스트용 사용자 ID
        int userId = 1;

        // 사용자 알림 목록 조회
        List<KTXAlertDO> alertList =
                alertDao.getAlerts(userId);

        // 조회 결과 전달
        request.setAttribute(
                "alertList",
                alertList
        );

        // 알림 목록 화면으로 이동
        request.getRequestDispatcher(
                "project_KTX/ktxAlertList.jsp"
        ).forward(request, response);
    }

    	//사용자 알림 삭제
    	public void deleteAlert(HttpServletRequest request, HttpServletResponse response) throws Exception {

    	// 삭제할 알림 번호
    	int alertId =
          Integer.parseInt(request.getParameter("alertId"));

    	// 현재 테스트용 사용자 ID
    	int userId = 1;

    	// 알림 삭제
    	alertDao.deleteAlert(
        alertId,
        userId);

    	// 삭제 후 알림 목록으로 이동
    	response.sendRedirect(request.getContextPath()+ "/KTX_train?action=list");
    }
    	// 취소표 발생 열차 조회
    public void availableTrains(HttpServletRequest request, HttpServletResponse response) throws Exception {

      String departure =
    	      request.getParameter("departure");

      String arrival =
    	      request.getParameter("arrival");

      String travelDate =
    	      request.getParameter("travelDate");

      String timeRange =
    	      request.getParameter("timeRange");

      String seatType =
    	      request.getParameter("seatType");


      // 좌석이 있는 열차 조회
      List<KTXDO> trainList =
    	      dao.findAvailableTrains(departure, arrival,travelDate, timeRange, seatType);

    	    // 조회 결과 전달
    	    request.setAttribute(
    	            "trainList",
    	            trainList
    	    );


    	    // 결과 화면으로 이동
    	    request.getRequestDispatcher(
    	            "project_KTX/ktxResult.jsp"
    	    ).forward(request, response);
    }
    public void checkAlerts( HttpServletRequest request, HttpServletResponse response) throws Exception {

    	// 테스트 사용자
        int userId = 1;

        // 등록된 알림 조회
        List<KTXAlertDO> alertList =
                alertDao.getAlerts(userId);

        // 알림별로 취소표 확인
        for (KTXAlertDO alert : alertList) {

            List<KTXDO> trainList =
                    dao.findAvailableTrains(
                            alert.getDeparture(),
                            alert.getArrival(),
                            alert.getTravelDate(),
                            alert.getTimeRange(),
                            alert.getSeatType()
                            );

            if (!trainList.isEmpty()) {

                System.out.println("취소표 발견!");

                // 취소표 발견 → 알림 상태 변경
                alertDao.updateAlertStatus(
                        alert.getAlertId(),
                        "FOUND"
                );

                System.out.println(
                        alert.getDeparture()
                        + " → "
                        + alert.getArrival()
                );

                System.out.println(
                        "시간대 : "
                        + alert.getTimeRange()
                );

                System.out.println(
                        "열차 수 : "
                        + trainList.size()
                );

                request.setAttribute(
                        "availableTrains",
                        trainList
                );

                request.setAttribute(
                        "foundAlert",
                        alert
                );

                request.getRequestDispatcher(
                        "project_KTX/ktxAlertFound.jsp"
                ).forward(request, response);

                return;
            }
        }
    }

    // 알림 목록에서 "예매 가능한 열차 보기" 눌렀을 때 - 그 알림 하나에 대해서만 조회
    public void viewFound(HttpServletRequest request, HttpServletResponse response) throws Exception {

        int alertId =
                Integer.parseInt(request.getParameter("alertId"));

        // 테스트 사용자
        int userId = 1;

        List<KTXAlertDO> alertList =
                alertDao.getAlerts(userId);

        KTXAlertDO target = null;

        for (KTXAlertDO alert : alertList) {
            if (alert.getAlertId() == alertId) {
                target = alert;
                break;
            }
        }

        // 알림을 못 찾으면(이미 삭제되었거나 다른 사용자) 목록으로 돌려보냄
        if (target == null) {
            response.sendRedirect(request.getContextPath() + "/KTX_train?action=list");
            return;
        }

        List<KTXDO> trainList =
                dao.findAvailableTrains(
                        target.getDeparture(),
                        target.getArrival(),
                        target.getTravelDate(),
                        target.getTimeRange(),
                        target.getSeatType()
                );

        request.setAttribute("availableTrains", trainList);
        request.setAttribute("foundAlert", target);

        request.getRequestDispatcher(
                "project_KTX/ktxAlertFound.jsp"
        ).forward(request, response);
    }

    // 예매 직전 확인 화면
    public void booking(
            HttpServletRequest request,
            HttpServletResponse response)
            throws Exception {

        int trainId =
                Integer.parseInt(
                        request.getParameter("trainId")
                );

        KTXDO train =
                dao.getTrain(trainId);

        request.setAttribute(
                "train",
                train
        );

        request.getRequestDispatcher(
                "project_KTX/ktxBooking.jsp"
        ).forward(
                request,
                response
        );
    }
}
