package project_KTX;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class KTXDAO {

	final String JDBC_DRIVER = "org.h2.Driver";
    final String JDBC_URL = "jdbc:h2:tcp://localhost/~/jwbookdb";


    // DB 연결
    public Connection open() throws Exception {

        Connection conn = null;

        Class.forName(JDBC_DRIVER);

        conn = java.sql.DriverManager.getConnection(
                JDBC_URL,
                "jwbook",
                "1234"
        );

        return conn;
    }


    // KTX 열차 검색
    public List<KTXDO> searchTrain(
            String departure,
            String arrival,
            String travelDate,
            String timeRange,
            int people,
            String seatType) throws Exception {


        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        List<KTXDO> trainList =
                new ArrayList<KTXDO>();


        String startTime =
                timeRange.substring(0, 5);

        String endTime =
                timeRange.substring(6, 11);


        String sql =
                "SELECT TRAIN_ID, DEPARTURE, ARRIVAL, "
                + "TRAVEL_DATE, DEPARTURE_TIME, ARRIVAL_TIME, "
                + "GENERAL_SEAT, SPECIAL_SEAT "
                + "FROM KTX_TRAIN "
                + "WHERE DEPARTURE = ? "
                + "AND ARRIVAL = ? "
                + "AND TRAVEL_DATE = ? "
                + "AND DEPARTURE_TIME >= ? "
                + "AND DEPARTURE_TIME < ? "
                + "ORDER BY DEPARTURE_TIME";


        try {

            // DB 연결
            conn = open();


            // SQL 준비
            pstmt = conn.prepareStatement(sql);


            // 조건 전달
            pstmt.setString(1, departure);

            pstmt.setString(2, arrival);

            pstmt.setString(3, travelDate);

            pstmt.setString(4, startTime);

            pstmt.setString(5, endTime);


            // SQL 실행
            rs = pstmt.executeQuery();


            // 검색 결과 처리
            while (rs.next()) {

                KTXDO train =
                        new KTXDO();


                train.setTrainId(
                        rs.getInt("TRAIN_ID")
                );

                train.setDeparture(
                        rs.getString("DEPARTURE")
                );

                train.setArrival(
                        rs.getString("ARRIVAL")
                );

                train.setTravelDate(
                        rs.getString("TRAVEL_DATE")
                );

                train.setDepartureTime(
                        rs.getString("DEPARTURE_TIME")
                );

                train.setArrivalTime(
                        rs.getString("ARRIVAL_TIME")
                );

                train.setGeneralSeat(
                        rs.getInt("GENERAL_SEAT")
                );

                train.setSpecialSeat(
                        rs.getInt("SPECIAL_SEAT")
                );


                trainList.add(train);
            }


        } catch (Exception e) {

            e.printStackTrace();

            throw e;


        } finally {

            try {

                if (rs != null) {
                    rs.close();
                }

                if (pstmt != null) {
                    pstmt.close();
                }

                if (conn != null) {
                    conn.close();
                }

            } catch (Exception e) {

                e.printStackTrace();
            }
        }


        return trainList;
    }
   
    // 취소표 발생 열차 조회
    public List<KTXDO> findAvailableTrains(
            String departure,
            String arrival,
            String travelDate,
            String timeRange,
            String seatType) throws Exception {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        List<KTXDO> trainList =
                new ArrayList<KTXDO>();

        // 시간대 분리
        String startTime =
                timeRange.substring(0, 5);

        String endTime =
                timeRange.substring(6, 11);

        // 좌석 종류에 따라 조건 결정
        String seatColumn;

        if ("일반실".equals(seatType)) {

            seatColumn = "GENERAL_SEAT";

        } else {

            seatColumn = "SPECIAL_SEAT";
        }


        String sql =
                "SELECT TRAIN_ID, DEPARTURE, ARRIVAL, "
                + "TRAVEL_DATE, DEPARTURE_TIME, ARRIVAL_TIME, "
                + "GENERAL_SEAT, SPECIAL_SEAT "
                + "FROM KTX_TRAIN "
                + "WHERE DEPARTURE = ? "
                + "AND ARRIVAL = ? "
                + "AND TRAVEL_DATE = ? "
                + "AND DEPARTURE_TIME >= ? "
                + "AND DEPARTURE_TIME < ? "
                + "AND " + seatColumn + " > 0 "
                + "ORDER BY DEPARTURE_TIME";


        try {

            // DB 연결
            conn = open();

            // SQL 준비
            pstmt = conn.prepareStatement(sql);

            // 검색 조건 전달
            pstmt.setString(1, departure);
            pstmt.setString(2, arrival);
            pstmt.setString(3, travelDate);
            pstmt.setString(4, startTime);
            pstmt.setString(5, endTime);

            // SQL 실행
            rs = pstmt.executeQuery();


            // 검색 결과 처리
            while (rs.next()) {

                KTXDO train =
                        new KTXDO();

                train.setTrainId(
                        rs.getInt("TRAIN_ID")
                );

                train.setDeparture(
                        rs.getString("DEPARTURE")
                );

                train.setArrival(
                        rs.getString("ARRIVAL")
                );

                train.setTravelDate(
                        rs.getString("TRAVEL_DATE")
                );

                train.setDepartureTime(
                        rs.getString("DEPARTURE_TIME")
                );

                train.setArrivalTime(
                        rs.getString("ARRIVAL_TIME")
                );

                train.setGeneralSeat(
                        rs.getInt("GENERAL_SEAT")
                );

                train.setSpecialSeat(
                        rs.getInt("SPECIAL_SEAT")
                );


                trainList.add(train);
            }


        } catch (Exception e) {

            e.printStackTrace();

            throw e;


        } finally {

            try {

                if (rs != null) {
                    rs.close();
                }

                if (pstmt != null) {
                    pstmt.close();
                }

                if (conn != null) {
                    conn.close();
                }

            } catch (Exception e) {

                e.printStackTrace();
            }
        }


        return trainList;
    }
   
    public KTXDO getTrain(int trainId) throws Exception {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        KTXDO train = null;

        String sql =
                "SELECT TRAIN_ID, DEPARTURE, ARRIVAL, "
                + "TRAVEL_DATE, DEPARTURE_TIME, ARRIVAL_TIME, "
                + "GENERAL_SEAT, SPECIAL_SEAT "
                + "FROM KTX_TRAIN "
                + "WHERE TRAIN_ID = ?";

        try {

            // DB 연결
            conn = open();

            // SQL 준비
            pstmt = conn.prepareStatement(sql);

            // 열차 번호 설정
            pstmt.setInt(1, trainId);

            // SQL 실행
            rs = pstmt.executeQuery();

            // 결과 처리
            if (rs.next()) {

                train = new KTXDO();

                train.setTrainId(
                        rs.getInt("TRAIN_ID")
                );

                train.setDeparture(
                        rs.getString("DEPARTURE")
                );

                train.setArrival(
                        rs.getString("ARRIVAL")
                );

                train.setTravelDate(
                        rs.getString("TRAVEL_DATE")
                );

                train.setDepartureTime(
                        rs.getString("DEPARTURE_TIME")
                );

                train.setArrivalTime(
                        rs.getString("ARRIVAL_TIME")
                );

                train.setGeneralSeat(
                        rs.getInt("GENERAL_SEAT")
                );

                train.setSpecialSeat(
                        rs.getInt("SPECIAL_SEAT")
                );
            }

        } finally {

            if (rs != null) {
                rs.close();
            }

            if (pstmt != null) {
                pstmt.close();
            }

            if (conn != null) {
                conn.close();
            }
        }

        return train;
    }
}
