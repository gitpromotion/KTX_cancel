package ch11;

import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;


@WebListener
public class ListenerExam implements ServletContextListener, ServletContextAttributeListener, HttpSessionListener, HttpSessionAttributeListener {

	//리스너 생성자
    public ListenerExam() {

    }

    public void sessionCreated(HttpSessionEvent se)  { 
    
    }
    //c
    public void attributeAdded(ServletContextAttributeEvent scae)  { 

    }

	
    public void attributeRemoved(ServletContextAttributeEvent scae)  { 

    }

	
    public void sessionDestroyed(HttpSessionEvent se)  { 

    }
    //ServletContext 종료
    public void contextDestroyed(ServletContextEvent sce)  { 

    }

	//ServletContext에 속성 추가
    public void attributeAdded(HttpSessionBindingEvent se)  { 

    }

    //ServletContext에 속성 변경
    public void attributeRemoved(HttpSessionBindingEvent se)  { 

    }

	//ServletContext에 속성 변경
    public void attributeReplaced(HttpSessionBindingEvent se)  { 

    }

	
    public void attributeReplaced(ServletContextAttributeEvent scae)  { 

    }
   
    //ServletContext 시작
    public void contextInitialized(ServletContextEvent sce)  { 
    	sce.getServletContext().log("ServletContext 종료됨!!");
    }
	
}
